<?php
// Heading
$_['heading_title'] = 'Панель состояния';
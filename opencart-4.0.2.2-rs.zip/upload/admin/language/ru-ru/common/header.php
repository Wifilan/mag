<?php
// Heading
$_['heading_title']          = 'Администрирование';

// Text
$_['text_notification']      = 'Уведомления';
$_['text_notification_all']  = 'Показать все';
$_['text_notification_none'] = 'Нет новых уведомлений';
$_['text_profile']           = 'Ваш профиль';
$_['text_store']             = 'Магазин';
$_['text_help']              = 'Помощь';
$_['text_homepage']          = 'Сайт ';
$_['text_support']           = 'Форум';
$_['text_documentation']     = 'Документация';
$_['text_logout']            = 'Выход';
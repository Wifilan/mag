<?php
$_['error_language'] = 'Внимание: Язык не найден!';
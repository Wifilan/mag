<?php
// Text
$_['text_recommended'] = 'Рекомендации';
$_['text_install']     = 'Установить';
$_['text_uninstall']   = 'Деинсталлировать';
$_['text_delete']      = 'Удалить';

<?php
// Heading
$_['heading_title'] = 'Отчеты';

// Text
$_['text_success']  = 'Настройки успешно изменены!';
$_['text_type']     = 'Выберите желаемый отчет';
$_['text_filter']   = 'Фильтр';
<?php
// Heading
$_['heading_title']    = 'Уведомления';

// Text
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_list']        = 'Список уведомлений';

// Column
$_['column_message']   = 'Сообщение';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для управления данным расширением!';